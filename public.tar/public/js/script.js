$(document).ready(function(){
  //This does not set the label to the active position:
  //$('.input-field label').addClass('active');
  
  //This does set the label to the active position.
  setTimeout(function(){ $('.input-field label').addClass('active'); }, 1);
});

$(document).ready(function() {
    $('textarea#text').keypress(function() {
        getReadingLevel($('textarea#text').val());
    });
});

 $(document).ready(function() 
 {
    $("#submit").click(function() 
    	{
    	getReadingLevel( $('textarea#text').val() );
    	}
    );
});

function getReadingLevel(text) {

	var url = 'level?text=' + encodeURIComponent(text);//var url = '/analysis/level?text=' + encodeURIComponent(text);

	$.ajax(url, {dataType: 'json'})

 	.done(function(result, status, json) {
        var statistics = json.responseJSON;
        $("#sentences").text("Number of Sentences: " + statistics.sentences);
        $("#words").text("Number of Words: " + statistics.words);
        $("#chars").text("Number of Characters: " + statistics.chars);
        $("#rlevel").text("Reading Level: " + statistics.level);
  	})

    .fail(function(error) {
        console.log(typeof error);
        console.log(error);
    })

    .always(function(data) {
        //console.log(typeof data);
    });

}